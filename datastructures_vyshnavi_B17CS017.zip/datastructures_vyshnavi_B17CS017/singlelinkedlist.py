#single linked list
class Node:
    def __init__(self,x):
        self.data=x
        self.next=None
class singleLinkedList:
    def __init__(self):
        self.head=None
    def insertAtBeginning(self,x):
        temp=Node(x)
        if self.head==None:
            self.head=temp
        else:
            temp.next=self.head
            self.head=temp
    def insertAtEnd(self,x):
        temp=Node(x)
        t=self.head
        if self.head==None:
            self.head=temp
        else:
            while(t.next!=None):
                t=t.next
            t.next=temp
    def delBegin(self):
        if(self.head==None):
            print("No element to delete")
        else:
            self.head=self.head.next
    def delEnd(self):
        t=self.head
        if self.head.next==None:
            self.head=None
        else:
            while t.next.next!=None:
                t=t.next
            t.next=None
    def display(self):
        t=self.head
        while t!=None:
            print(t.data, end=" ")
            t=t.next
        print()
            
obj=singleLinkedList()
n=int(input("enter no. of elements\n"))
while(n>0):
    x=int(input())
    obj.insertAtBeginning(x)
    #obj.insertAtEnd(x)
    n=n-1
obj.display()
obj.delBegin()
obj.display()
obj.delEnd()
obj.display()
            
    