lst=[]
n=int(input("enter the range "))
lst=list(range(1,n+1))

#create a list of items with squares of list "lst" using map 
l=list(map(lambda x:x**2,lst))
print(l)

#filter all elements which are in range n from list "l"
lst1=list(filter(lambda x:x<=n,l))
print(lst1)