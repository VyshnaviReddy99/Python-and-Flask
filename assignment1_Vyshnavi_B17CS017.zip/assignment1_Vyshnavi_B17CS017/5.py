import re
f1=open("data.txt","r") 
f2=open("answer.txt","w+")
data=f1.read()

name=r'^[A-Z][a-z]+\s[A-Z][a-z]+'
phnNo= r'[0-9]{3}[-][0-9]{3}[-][0-9]{4}'
add= r'([0-9]+\s)([A-Z][a-z]+\s)[A-Z][a-z](.,\s)[A-Z.a-z]+\s[A-Z]+\s[0-9]+'
email= r'[a-z]+@[a-z]+\.[a-z]+'

names = re.finditer(name,data, re.MULTILINE)
f2.write("Names are:\n")
for matchNum, match in enumerate(names, start=1): 
	f2.write(match.group())
	f2.write("\n")

add_match = re.finditer(add,data, re.MULTILINE)
f2.write("\nAddress are:\n")
for matchNum, match in enumerate(add_match, start=1): 
	f2.write(match.group())
	f2.write("\n")


phn_match= re.finditer(phnNo, data, re.MULTILINE)
f2.write("\nPhone No's are:\n")
for match in phn_match:
	f2.write(match.group())
	f2.write("\n")

f2.write("\nData after change:\n ")
data_req= data.replace('Dave','John')
f2.write(data_req)

f1.close()
f2.close()

