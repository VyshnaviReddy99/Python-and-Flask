from time import time

def logger_function(fn):
    def wrapper_func(*args,**kwargs):
        t1=time()
        print("logged at {}".format(t1))
        result=fn(*args,**kwargs)
        t2=time()
        print("loggedout at {}".format(t2))
        print("time taken for execution is {} seconds".format(t2-t1))
        return result
    return wrapper_func
    
def execution_func(func):
    def wrapper(*args,**kwargs):
        print(func(*args,**kwargs))
        return func
    return wrapper

@logger_function
@execution_func
def logger(x):
    return x**2
logger(1000)