import collections
n=int(input("enter the range"))
l=list(range(n,0,-1))
deque_obj=collections.deque(l)
for i in range(n):
    deque_obj.rotate(1)
    for j in deque_obj:
        print(j,end=" ")
    print("")